
public interface Bag {
	public Object get();

	public void set(Object o);
}
