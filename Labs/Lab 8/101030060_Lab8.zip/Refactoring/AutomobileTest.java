
public class AutomobileTest {
	public void race() {
		Automobile2 car1 = new Automobile2();
		car1.setMake("Austin Healy");
		car1.setModel("Sprite");
		// ...
	}
}
