
public class MessagePipe {

	public MessagePipe() {
		
	}
	
	public void send(Bag bag) {
		
	}
}
